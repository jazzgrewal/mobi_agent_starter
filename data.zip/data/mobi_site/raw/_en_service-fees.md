# Service Fees - Mobi by Rogers

**URL:** https://www.mobibikes.ca/en/service-fees
**Description:** 
**Main Heading:** 
**Scraped:** 2025-11-10 22:46:33

---

### Overage fees & Penalties

### **Overage Fees**

Fees incurred when the Rider goes over the allotted ride time of their plan.  
  
**Classic Bikes:** $0.29 /min.  
**Ebikes:**Only applicable to UBC Pass – $0.19/min.

### **Late Return**

Fee charged when a Bike notifies of a lock error and is left active at a station.

**GENERAL PASS HOLDERS**

**Classic Bikes:**$15  
**Ebikes:**$30  
  
**COMMUNITY PASS HOLDERS**

**Classic Bikes:**$5  
**Ebikes:**$15

### **Loss of Use**

Rate charged if a Bike is lost, stolen or forced out of use due to damage. Charged after the Bike is found.  
  
**Classic Bikes:**$5 /day  
**Ebikes:**$15 /day

### **Reinstatement Fee**

Cost to reinstate membership after a Bike is reported missing or after an account has been suspended.

**GENERAL PASS HOLDERS**

$25  
  
**COMMUNITY PASS HOLDERS**

$20

### **Replacement Fee**

Mobi reserves the right to charge up to the full cost of replacing equipment  
  
**Classic Bikes:**$2,000  
**Ebikes:**$4,000

### Recovery, Cleaning and Damage Fees

### **Pick up & Recovery (within service area)**

Cost of recovering, inspecting and rebalancing a Bike within Mobi's service area (includes VPD pick-ups) - **Up to $50**

### **Pick up & Recovery (outside of service area)**

Cost of recovering, inspecting and rebalancing a Bike outside of Mobi's service area (includes VPD pick-ups) - **Up to $80**

### **Excessive Cleaning Fee**

Extra cleaning required when a Bike is returned unusable due to uncleanliness - **Up to $80**

### **Minor Damage Repair**

If a Bike is damaged during your Rental Period of the Bike, beyond regular wear and tear, you shall be charged a fee that is equal to the cost of repairing such damage. Ex. - Switching lights, saddle replacement, small graffiti - **Up to $100**

### **Major Damage Repair**

If a Bike is damaged during your Rental Period of the Bike, beyond regular wear and tear, you shall be charged a fee that is equal to the cost of repairing such damage. Ex. - Full resticker, large graffiti, broken frame, wheels, forks, etc. - **Up to the replacement fee**