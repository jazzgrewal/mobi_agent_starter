# Privacy policy - Mobi by Rogers

**URL:** https://www.mobibikes.ca/en/privacy-policy
**Description:** 
**Main Heading:** Privacy policy
**Scraped:** 2025-11-10 22:46:22

---

# Privacy policy

Updated on: 16 May 2025

**VANCOUVER BIKE SHARE DBA MOBI BY ROGERS**  
**PRIVACY POLICY**  
   
Our ongoing commitment to protect the privacy and confidentiality of your Personal Information is addressed in this Privacy Policy. Our Privacy Policy complies with the applicable requirements of the Personal Information Protection Act (British Columbia), the Personal Information Protection and Electronic Documents Act (Canada), and the Canadian Standards Association Model Code for the Protection of Personal Information.   
  
This Privacy Policy provides information on how we collect, store, use and disclose Personal Information provided to us in the course of participating in the Vancouver Bike Share (“**VBS**”) and / or the VBS membership application process, and during the time that you are a VBS member.   
  
VBS is a public bike-sharing program operated by Vancouver Bike Share Inc., a subsidiary of CycleHop LLC.  
  
**Personal Information**  
  
Personal Information is defined in this Privacy Policy as:

- information that establishes your identity (for example, your name, address, phone number, date of birth, etc.), but does not include aggregate data from which we have removed personal identifiers or your business contact information;
- information related to your use of the VBS Program including geolocation data (“Geolocation Data”);
- information that you provide on your application for VBS membership or in setting up and managing your VBS account, including information required to confirm and/or establish your eligibility for corporate and community memberships; and
- your financial information (such as credit account card numbers) and information about your financial behavior (such as your payment history),

(collectively, your “Personal Information”).  
  
**Collection of Personal Information**  
  
We may, from time to time, collect and confirm your Personal Information as part of your application for VBS membership and throughout the term of your VBS membership. We collect Geolocation Data only when authorized to by you in the settings of the VBS mobile app (i.e., you have the ability to manage (including removing) your authorization to collect Geolocation Data in the app settings), and only when you are using the VBS mobile app during the term of your VBS membership.   
  
We collect, use and disclose such Personal Information to:

- operate our bike share program;
- to support, personalize and optimize your use of, and experience with, our bike share services; and
- to communicate with you regarding our services and products.

**Use and Disclosure of Personal Information**  
  
We may use the Personal Information that we collect from you from time to time for the following purposes:

- to verify your identity or complete a payment transaction that is authorized by you;
- to grant you rights to special memberships, including community and corporate memberships;
- to communicate to you any benefit, feature, service or other information about your VBS membership and the VBS program;
- to promote VBS related products or services, as well as products or services of sponsors and partners which may be of interest to you;
- to help us better manage the VBS program and your relationship with us;
- to accurately show you VBS bikes near your location, and accurately record your trip information (including location and distance travelled);
- to send, deliver or display advertising to you via digital channels (including on-line and email); and
- as otherwise required or permitted by law.

For the above purposes, we may make your Personal Information available to our employees, affiliates, agents, service providers, insurers and partners who are required to maintain the confidentiality of your Personal Information. For the purposes of this Privacy Policy, affiliates include any entity that we control, controls us, or is under common control with us, and their successors.   
  
We may disclose your Personal Information from time to time for the following purposes:

- to verify or process your credit or debit card payments in the context of transactions that have been authorized by you;
- to prevent fraud, such as disclosure to credit reporting fraud checking agencies;
- to administer insurance claims; and
- to comply with regulatory, statutory and legal obligations where disclosure is required or otherwise authorized by law.

We may share your Personal Information with regulators, government agencies, public bodies or other entities who have a right to issue requests for your Personal Information. Additionally, if acquired by or merged with another company, your Personal Information that we hold will be one of the assets transferred to such other company.   
  
**Third Party Service Providers**  
  
We use trusted third-party service providers, Stripe and Zendesk (the “**Third-Party Service Providers**”), to help us operate key aspects of the VBS program, including payment processing and customer support. These providers may collect, store, or process your Personal Information on our behalf and in accordance with this Privacy Policy.  ​​

- **Payment Processing – Stripe**  
  We use Stripe, a third-party payment processing company, to securely process credit and debit card transactions. Stripe may collect Personal Information from you in connection with a payment, including your card data, and may store and process this information on servers located outside of Canada, including in the United States.   
    
  Stripe may also provide us with limited information—such as your name, card type, expiration date, and the last four digits of your card number—which we use solely for the purpose of facilitating payments or managing ongoing membership plans that require recurring billing.
- **Customer Support – Zendesk**  
  We use Zendesk, a third-party customer service platform, to manage and respond to member inquiries and support requests. Any Personal Information you provide in a support ticket, email, web form, live chat, or any other form of support inquiry may be stored and processed outside of Canada, in any jurisdiction where Zendesk or its affiliates operate, including in the United States.

While your information is stored outside of Canada by the Third-Party Service Providers, it may be subject to the laws of those jurisdictions, including lawful access requests by government authorities. We take appropriate contractual and technical safeguards to ensure your Personal Information remains protected and is handled in accordance with applicable privacy laws and this Privacy Policy.  
  
**Consent**  
Your knowledge and consent are required for the collection, use or disclosure of your Personal Information, except as required or permitted by applicable law.  
  
**By reviewing this Privacy Policy and becoming a member of Vancouver Bike Share, you expressly consent to the collection, use and disclosure of your Personal Information for the purposes and in the manner set out in this Privacy Policy.**  
  
You may withdraw your consent to the collection, use and disclosure of your Personal Information within ten (10) days of applying for a VBS membership by contacting Vancouver Bike Share Inc. by way of our contact information provided below. In addition, you may withdraw your consent to our collection, use or disclosure of your Personal Information at any time by notice to our contact information provided below, but you may not withdraw your consent if such withdrawal of consent would frustrate the performance of a legal obligation, including to a credit reporting agency.  
  
**Limiting Use, Disclosure and Retention**  
  
We do not use or disclose your Personal Information for any purpose other than the purpose for which it was collected, except with your consent or as required or permitted by applicable law. We retain your Personal Information only as long as necessary to fulfill the purposes for which it was to be used and disclosed. For certainty, we do not retain Geolocation Data.  
  
**Accuracy/Correction of Personal Information**  
  
We keep your Personal Information as accurate, complete and up-to-date as is necessary and reasonably practical for the purposes for which it is to be used. It is your responsibility to inform us of any changes to your Personal Information that occur during the course of your membership. You may make correction requests to correct inaccuracies in your Personal Information. If such a request is made, we will correct the Personal Information or annotate your file to indicate that the correction request was made.  
  
**Security and Safeguarding your Personal Information**  
  
We protect your Personal Information by using safeguards that are appropriate to the sensitivity of the particular information. All our employees are informed about our Privacy Policy and their responsibilities to protect your Personal Information. We use comprehensive security controls to protect your Personal Information against unauthorized access, use, alteration, duplication, destruction or disclosure. While we do use third party contractors to assist us, we use appropriate contractual measures with those third parties to ensure protection of your Personal Information. From time to time, your Personal Information may be stored outside of Canada, in which case it may be subject to the lawful access requirements of the jurisdiction in which it is held.  
  
**Changes to our Privacy Policy**  
  
We reserve the right to change this Privacy Policy from time to time.  
  
**Collection Through Our Website**  
  
When you visit the VBS website, whether or not you are a member, we will collect your internet protocol (IP) address. We also use cookies to identify you as a return visitor and allow you to personalize our website to reflect your preferences and to store Personal Information that you have voluntarily provided through the website. We may also collect information such as the web browser used to access our website, and other information on a consolidated basis for statistical and survey purposes. Some of your Personal Information may also be used to deliver partner and product information based upon your preferences.   
  
**Communication and CASL**  
  
We may communicate with you in various ways, including by telephone, email, your VBS member account or mail, using the contact information you have provided. If we are communicating with you by phone, we may record calls for quality assurance.  
Upon registering to become a VBS member, you must expressly agree or disagree to receive Commercial Electronic Messages (“CEM”) from us. CEMs include emails, messages to social networking accounts and text messages. If you agree, you may still withdraw your consent to receive CEMs from us at any time by unsubscribing using the process provided in the electronic message itself, or by contacting us.

**Contact Us**  
   
Please direct any questions or complaints regarding our handling of your Personal Information, or any other questions about this Privacy Policy to:  
  
VBS Privacy Officer  
778-655-1800

[info@mobibikes.ca](mailto:info@mobibikes.ca)