# Terms and conditions - Mobi by Rogers

**URL:** https://www.mobibikes.ca/en/terms-and-conditions
**Description:** 
**Main Heading:** Terms and conditions of use
**Scraped:** 2025-11-10 22:46:48

---

# Terms and conditions of use

Updated on: 16 May 2025

**VANCOUVER BIKE SHARE RENTAL AGREEMENT & WAIVER (“AGREEMENT”)**

PLEASE READ THIS AGREEMENT CAREFULLY BEFORE RENTING OR USING A CLASSIC BICYCLE (“**CLASSIC BIKE**”) OR ELECTRIC BIKE (“**EBIKE**”) (CLASSIC BIKES AND EBIKES ARE EACH REFERRED TO HEREIN AS A “**BIKE**”) FROM VANCOUVER BIKE SHARE INC. AND CYCLEHOP, LLC dba MOBI BY ROGERS GO OR ANY OF THEIR AFFILIATES (COLLECTIVELY, "**VBS**"); VBS AND SMOOVE SAS. ARE JOINTLY REFERRED TO HEREIN AS "**OPERATOR**".

BY RENTING OR USING A BIKE, YOU AGREE TO ALL OF THE TERMS AND CONDITIONS CONTAINED WITHIN THIS AGREEMENT, INCLUDING, BUT NOT LIMITED TO, THE WAIVERS, RELEASES AND LIMITATIONS OF LIABILITY SET FORTH HEREIN. YOUR CONSENT IS EFFECTIVE IMMEDIATELY FOLLOWING YOUR ACCEPTANCE OF THIS AGREEMENT.  IF YOU DO NOT AGREE WITH ALL OF THE TERMS AND CONDITIONS OF USE SET FORTH IN THIS AGREEMENT, YOU ARE NOT PERMITTED TO RENT OR USE A BIKE FROM OPERATOR OR ITS AFFILIATES.

TAKE NOTE THAT TO PURCHASE A RENTAL PLAN (“**PASS**” or “**MEMBERSHIP**”) AND/OR TO RENT A BIKE, YOU MUST BE AT LEAST: (i) FOR EBIKES, 19 YEARS OF AGE; or (ii) FOR CLASSIC BIKES, 12 YEARS OF AGE AND ASSISTED BY AN ADULT IN THE MANNER OUTLINED IN THIS AGREEMENT.

PARTIES, CONSIDERATION AND BIKE SHARE PROGRAM DESCRIPTION

1.              AGREEMENT.  This Agreement is between the user (“**you**” or “**Rider**”) and the Operator.

1.1           CONSIDERATION:  In consideration of the Operator renting a Bike to you, you agree to all the terms, conditions and provisions contained within this Agreement.

1.2           EQUIPMENT.  The Operator maintains a network of hub stations (“**Stations**”) where Bikes are docked at Bike racks (“**Rack**”) using an electronically controlled lock (“**Lock**”). Signs are located at some Stations which provide instructions for payment. Bikes are equipped with Smoove Box devices. All of the foregoing equipment and other equipment located at a Station or that consists of any Bike, in whole or part, is referred to herein as “**Operator Equipment**.”

1.3           HOW IT WORKS.

(a)            REGISTRATION AND PURCHASE.  You must register for a Rider account (“**Account**”), including providing credit card info in accordance with Section 2.11, and purchase a Pass or Membership via: (i) the Operator’s website; (ii) the mobile app; or (iii) other applicable third party apps. These registration and payment obligations do not apply to VIP group passes or community passes that are registered and paid for separately; note however that the other obligations set out in this Agreement still apply to Riders holding VIP group or community passes.

(b)            METHOD OF RENTAL.  Once you have acquired a Pass or Membership, you can rent an available Bike in one of the following ways: (i) enter your Account number and PIN code at the Smoove Box located on the Bike; or (ii) tap your Membership card and enter your PIN code at the Smoove Box located on the Bike. Group rides organized separately with the Operator may also enable access to Bikes to applicable Riders; take note that such Riders are still subject to the terms and conditions of this Agreement.

(c)            RENTAL PERIOD.  Your Bike rental period (“**Rental Period**”) begins when the Bike is unlocked from a Rack at a Station. You take the Bike for a trip (“**Trip**”), and the Rental Period ends when the Bike is returned to a Station. To end the Rental Period, you must lock the Bike to an available Rack, and wait for verification on the Bike screen, Return OK, and audio signal of one beep, indicating the Rental Period has ended prior to leaving the Bike. If Rider has difficulty ending a Trip, Rider must make reasonable effort to troubleshoot the situation such as but not limited to removing the Bike from the Rack to retry ending the Trip, using a different available Rack in the same Station, or using a Rack in an alternative Station. If the difficulty persists, Rider must contact Operator at 778-655-1800 or info@mobibikes.ca for assistance. In accordance with Section 2.8, fees, in addition to any applicable overage fees, may be applied to Rider for Trips where the Rental Period has not been properly ended as determined by the Operator in its sole discretion.

(d)            STOPOVER.  Stopover is a feature of every Bike that allows you to secure and lock your Bike outside of a station. It is meant for quick stops or short breaks taken away from the Bike. Your Trip time will still be counted while the Bike is out of a Station and will contribute to incurring overage fees, if applicable. To engage Stopover, press “Enter” on the screen, scan your card if applicable, and enter your PIN. Remove the cable lock from the right side of the handle bar and loop it around a secure structure in a secure location (take note that a failure to adequately secure the Bike may lead to fees charged in accordance with Section 10 for lost or stolen Bikes). To disengage stopover, simply press “Enter” on the screen again and input your PIN.

(e)            BOUNDARIES.  All Trips must begin and end at a Station. Trips cannot terminate outside of the VBS program area designated on the map posted at each Station or available on the website and app (“**Program Area**”), and any Bike left outside the Program Area will be considered stolen with fees charged in accordance with Section 2.7.

2.              RENTAL RULES.

2.1           RENTAL PLANS.  

(a)            You may acquire from the Operator a rental plan at the applicable rate structure posted by the Operator from time to time on (i) the Operator’s website; (ii) the mobile app; or (iii) other applicable third party apps.

(b)            You are responsible for payment of the rate corresponding to the rental plan that you select, which rental plan may entail different pricing depending on rentals for Classic Bikes and Ebikes.

(c)            The Operator may, at its sole discretion, offer, from time to time, sales on select rental plans, special group pricing, and/or community passes, and may establish corresponding terms and conditions, including (but not limited to) with respect to eligibility, availability and pricing thereof.

2.2           AUTOMATIC RENEWAL. Unless otherwise provided by the Operator or in this Agreement, all the following Passes and Membership are automatically renewed unless cancelled at least one (1) day prior to the end of their term:

(a)            all annual memberships (sale memberships renew as regular priced memberships), except Community Passes; and

(b)            all monthly memberships.

To remove auto-renew on or cancel a Pass or Membership, Riders must login to their Account at [www.mobibikes.ca](http://www.mobibikes.ca/) or on the Operator mobile app and carry out the steps outlined therein to cancel their Pass or Membership.

2.3           UNUSED RENTAL TIME. Any unused rental time under a Pass or Membership cannot be carried over from one day to another day. For example, if you purchase a 30 Day Pass and do not rent a Bike on a given day within the applicable 30 day-period, you are not permitted to “bank” time from that calendar day to any other day.

2.4           OVERAGE FEES.  You will be charged overage fees when a Trip exceeds the time period corresponding to the particular Pass or Membership you have purchased, as set out in Section 10.1. You hereby agree to pay all overage fees incurred under your particular Pass or Membership. You assume all risks and responsibilities for tracking the duration of each Trip undertaken pursuant to your Pass or Membership. All overage fees are subject to tax.

2.5           MAXIMUM RENTAL TIME.  If a Bike is not returned to a Station within 16 hours of the start of a Rental Period (the “**Maximum Rental Time**”), the Operator may, in its sole discretion, deem the Bike to be stolen and charge you fees in accordance with Section 10.

2.6           REPAIR FEE.  If a Bike is damaged during your Rental Period of the Bike, beyond regular wear and tear, you will be charged fees in accordance with Section 10.

2.7           LOST OR STOLEN BIKE – SUSPENSION AND FEE.

(a)            General – Your Account will be suspended in accordance with Section 2.20 if:

(i)             you leave a Bike unlocked or unattended and it is stolen;

(ii)            a Bike is lost or stolen through your fault as determined by the Operator in its sole discretion; or

(iii)           a Bike is not returned to a Station within the Maximum Rental Time set out in Section 2.5.

If stolen, the Rider is responsible for promptly reporting the theft to the police and promptly providing the file number of the police report to the Operator. If the Bike is located, the Operator will complete a full inspection and damage report, as well as a full maintenance check. The Operator will then assess any fees owing pursuant to this Agreement, including fees set out in Section 10 and full replacement costs if the Bike is not found or is significantly damaged when found. If the Operator determines, in its sole discretion, that the loss or theft was not a result of wilful misconduct, gross negligence or repeat system abuse (including repeat breach of this Agreement) by the Rider, then on payment by the Rider of the fees assessed by the Operator (if any), the Operator will reinstate the Rider’s Account.

(b)            Community Pass Holder – If a Bike becomes lost, stolen, or damaged while under the care or responsibility of a Rider holding a Community Pass, the Operator may, in its sole discretion:

(i)             suspend such Rider from the right to rent any Bike for a period of up to one (1) year; or

(ii)            require the Rider to pay a one-time fee of up to $250 for a Classic Bike or $1,500 for an Ebike,

and to access a Bike again, the Community Pass holder must first meet with an approved Operator Employee to review proper bike use procedure.

(c)            Community Partner Pass holder – If a Bike becomes lost, stolen, or damaged while under the care or responsibility of a Rider holding a non-renewable Annual Pass issued by the Operator to a community partner, the Rider and the applicable community partner are jointly liable for any damages caused. In addition, the Operator may, in its sole discretion:

(i)             suspend such Rider from the right to rent any Bike for a period of up to one (1) year; or

(ii)            require the Rider and/or the applicable community partner to pay a one-time fee of up to $250 for a Classic Bike or $1,500 for an Ebike.

and to access a Bike again, such Rider must first meet with the Operator’s equity program coordinator to review proper bike use procedure.

2.8           LATE RETURN FEE.  When the Operator receives a system notification of a Bike that has not been properly docked back into a Station, and no attempt has been made by the Rider to end the Trip as required under Section 1.3(c), the Operator will pardon and/or waive the first occurrence and any resulting overage fees, but will charge a late return fee and overage fees in accordance with Section 10 for all subsequent infractions. Three repeat occurrences of such infractions without promptly contacting the Operator will result in a suspension in accordance to Section 2.20, and corresponding fees that must be paid by the Rider to the Operator before the Account suspension is lifted by the Operator.

2.9           HELMET USAGE.  You expressly acknowledge that applicable laws and ordinances require each Rider to wear an appropriate protective helmet designed for riding bicycles. You are solely responsible for yourself and any other permitted users who are renting Bikes under your Account to ensure that each of you wears a helmet and complies with the law. For convenience, a Mobi helmet (“**Helmet**”) is attached to each Bike or is available elsewhere as indicated on Station signs or the Bike Share Program website – and its use is included in the Bike rental fee or other payment as indicated. Helmets are only provided for use during a Rental Period and must be returned at the same time that a Trip is concluded. If you do not return a Helmet, you may be charged a Helmet fee of $50. Failure to wear a helmet while riding a Bike may result in fines, tickets, citations, or loss of ridership privileges, all of which is the sole responsibility of the Rider, and Operator assumes no responsibility or liability whatsoever as a result of a failure to wear a helmet while riding a Bike (including in respect of any property or bodily damage). Helmets are deemed to be included in the definition of “**Bike**” for the purpose of this Agreement.

2.10        VIOLATIONS.  You shall be completely responsible, and shall indemnify the Operator, for all tickets and fees assessed against the Bike or the Operator during your Rental Period or as a result of the location where you parked the Bike. You are responsible for all tickets and moving violations incurred during the Rental Period, including those resulting from your failure to wear a helmet. You agree to reimburse the Operator for any costs, expenses and attorney’s fees for processing, pursuing and/or defending any such claims.

2.11        CREDIT CARD.

(a)            General – Except as otherwise provided in this Section 2.11 you must provide the Operator a valid credit card number with expiration date (“**Credit Card**”) before being registered to use a Bike. This Credit Card will be verified for its validity through a one-time $25 card verification anytime the Credit Card is added to Rider Account and prior to any applicable electronic payment process; such amount will be applied and then immediately cancelled and/or refunded. Pre-paid credit cards are not considered a valid method of payment. By providing your Credit Card to the Operator, you represent and warrant to the Operator that you are authorized to use such Credit Card. You further authorize the Operator to charge the Credit Card for all costs (including fees, expenses and tickets) incurred by you under this Agreement, and acknowledge and agree that all such costs are subject to applicable taxes and other local government charges, which may be charged and collected by the Operator. In the event that your Credit Card is declined for any reason, the Operator may immediately suspend your rental plan and ability to use any Bikes until all of your prior charges are paid in full, including a reinstatement fee of up to $30.

(b)            Community Partners – If you hold a Pass issued by the Operator to a community partner, such community partner will be responsible for providing a Credit Card to the Operator and making the authorizations outlined above; however, the applicable community partner may choose to collect all costs, fees and expenses accrued pursuant to this Agreement (including tickets), applicable taxes and local government charges from you if agreed-to in advance with the Operator.

(c)            Community Pass Holder – Holders of a Community Pass may, in addition to payment by valid credit card, provide payment for all or any costs, fees and expenses accrued pursuant to this Agreement (including tickets), applicable taxes and local government charges by cash or debit payment using the Square software.

2.12        CREDITS.  The Operator may issue time or other credits (“**Credits**”) to you to be used toward future Trips. Credits shall have no monetary value. Credits may be transferred to family or friends as approved by the Operator but may not be sold. No monetary exchange is permitted for Credits on Rider Account. If any Credit has an expiration date, it will be noted in your Account page. Unused Credits will expire and be removed from your Account at the end of any applicable validity period. The terms outlined in this Agreement are applicable to all Bike usage whether or not a Credit is applied to the Trip.

2.13        THIRD PARTY PAYMENT PROCESSOR.  

(a)            The Operator uses a third party payment processing company called Stripe. In collecting payment, Stripe processes your credit card transactions and obtains personal information from you. Stripe provides some or all of the services from systems located within the United States. As such, your credit card data (“**Card Data**”) and personal information will be transferred, processed and stored outside of Canada on servers in the United States, and may be subject to disclosure as required by applicable law. Stripe may provide the Operator with information such as your name, credit card type, expiration date, and the last four digits of your credit card number. This information is only used to make single payment requests, or register the Rider for an ongoing membership plan that requires automatic payments in the future. For more information on Stripe’s payment processing and security practices, please visit <https://stripe.com/ca/privacy> and <https://stripe.com/ca/terms#section_a>.

(b)            Take note that if you object to your personal information and/or Card Data being processed and stored in this manner, you cannot use the Operator’s Bike rental service. By registering for the Bike rental service pursuant to this Agreement and providing valid payment, you expressly consent to the Operator’s use and disclosure of your personal information and Card Data in the manner described in this Agreement. 

2.14        RENTAL OF MULTIPLE BICYCLES.  Subject to program requirements and availability, a Rider over the age of 19 who purchases a Pay Per Ride Pass may rent up to four (4) Bikes at the same time on that Rider’s Account. If a Rider elects to rent multiple Bikes at the same time, such Rider (referred to as the “**Main Rider**” for the purposes of this Section 2.14) agrees to rent the first Bike for the Main Rider's own use and to make subsequent Bikes available to additional users (each, an “**Additional User**”) under the Main Rider’s Account. Prior to riding, each Additional User must review and accept this Agreement, except such requirements outlined herein to create an Account. The Main Rider further acknowledges and agrees that:

(a)            the Main Rider shall be responsible for each Bike rented under the Main Rider's Account;

(b)            that each Additional User is at least 12 years of age (for Classic Bikes), and at least 19 years of age (for Ebikes);

(c)            the Main Rider is responsible for ensuring that each Additional User reads and complies with this Agreement, except such requirements outlined herein to create an Account; and

(d)            the Main Rider is fully and completely responsible and liable for all Claims (as defined in Section 5.1) arising from or related to all Additional User(s)’ use(s) of a Bike/Bikes.

2.15        RIDERS 19 YEARS AND OLDER. This Agreement applies to all Additional Users who are at least 19 years of age. Each such Additional Users will be deemed to be a “**Rider**” under this Agreement, with the exception that such Additional Users will not need to set up their own Account, and it is the responsibility of each Rider, including Additional Users, to read and comply with this Agreement, including, without limitation, in respect of Section 5 (Release and Limitation of Liability), Section 6 (Assumptions of Risks Disclaimer) and Section 8 (Indemnification). Any liability of an Additional User under these and other sections of this Agreement will be joint and several with the Main Rider whose Account was used to rent a Bike. Use of any the Operator Equipment will be deemed to be acceptance of the terms of this Agreement.

2.16        RIDERS UNDER THE AGE OF 19. In the event that the Main Rider is renting multiple Bikes and one or more of the Additional User(s) is under 19 years of age, the Main Rider agrees to the following:

YOU HEREBY AFFIRM THAT:

(i)             YOU ARE THE PARENT OR LEGAL GUARDIAN OF EACH ADDITIONAL USER(S) WHO IS UNDER 19 YEARS OF AGE;

(ii)            YOU ARE AT LEAST 19 YEARS OF AGE AND EACH ADDITIONAL USER USING A CLASSIC BIKE IS: (i) AT LEAST 12 YEARS OF AGE; AND (ii) AT LEAST 150 CM IN HEIGHT;

(iii)           YOU WILL NOT PERMIT ANY ADDITIONAL USER UNDER 19 YEARS OF AGE TO USE ANY EBIKE AT ANY TIME;

(iv)           YOU HAVE THE LEGAL AND MENTAL CAPACITY TO ENTER INTO THIS AGREEMENT;

(v)            YOU HAVE ENSURED THAT EACH ADDITIONAL USER WHO IS UNDER 19 YEARS OF AGE HAS READ AND UNDERSTOOD THIS AGREEMENT AND THAT, IF NECESSARY, YOU HAVE EXPLAINED THE TERMS OF THIS AGREEMENT TO SUCH ADDITIONAL USER(S);

(vi)           YOU ARE AGREEING TO THIS AGREEMENT (INCLUDING, WITHOUT LIMITATION, SECTION 3 (RESTRICTIONS AND OTHER TERMS AND CONDITIONS OF BIKE USE), SECTION 5 (RELEASE AND LIMITATION OF LIABILITY), SECTION 6 (ASSUMPTIONS OF RISKS DISCLAIMER) AND SECTION 8 (INDEMNIFICATION) ON BEHALF OF EACH SUCH ADDITIONAL USER;

(vii)         YOU AUTHORIZE THE USE OF YOUR ACCOUNT FOR BIKE RENTAL SERVICES BY EACH SUCH ADDITIONAL USER IN ACCORDANCE WITH THIS AGREEMENT, INCLUDING THE RESTRICTIONS AND OTHER TERMS AND CONDITIONS OF BIKE USE OUTLINED FOR RIDERS IN SECTION 3 WHICH APPLY TO EACH ADDITIONAL USER; AND

(viii)        YOU ARE RESPONSIBLE FOR EACH ADDITIONAL USER’S COMPLIANCE WITH ALL APPLICABLE PROVISIONS OF THIS AGREEMENT.

2.17        RIDERS AGED 12 TO 18.  A parent or legal guardian of a Rider that is at least twelve (12) years old but less than nineteen (19) years old (a “**Youth Rider**” for the purposes of this Section 2.17), may purchase a Pass to only use a Classic Bike (i.e., not an Ebike) for the Youth Rider, but by purchasing a Pass for such a Youth Rider, the parent or legal guardian is hereby responsible for all the duties and responsibilities set out in this Agreement of such Youth Rider. 

In addition, THE PARENT OR LEGAL GUARDIAN HEREBY AFFIRMS THAT:

(i)             YOU ARE THE PARENT OR LEGAL GUARDIAN OF THE YOUTH RIDER;

(ii)            YOU ARE AT LEAST 19 YEARS OF AGE AND THE YOUTH RIDER IS AT LEAST 150 CM IN HEIGHT;

(iii)           YOU HAVE THE LEGAL AND MENTAL CAPACITY TO ENTER INTO THIS AGREEMENT;

(iv)           YOU HAVE ENSURED THAT THE YOUTH RIDER HAS READ AND UNDERSTOOD THIS AGREEMENT AND THAT, IF NECESSARY, YOU HAVE EXPLAINED THE TERMS OF THIS AGREEMENT TO SUCH YOUTH RIDER;

(v)            YOU ARE AGREEING TO THIS AGREEMENT (INCLUDING, WITHOUT LIMITATION, SECTION 3 (RESTRICTIONS AND OTHER TERMS AND CONDITIONS OF BIKE USE), SECTION 5 (RELEASE AND LIMITATION OF LIABILITY), SECTION 6 (ASSUMPTIONS OF RISKS DISCLAIMER) AND SECTION 8 (INDEMNIFICATION) ON BEHALF OF THE YOUTH RIDER;

(vi)           YOU AUTHORIZE THE USE OF YOUR ACCOUNT FOR BIKE RENTAL SERVICES BY THE YOUTH RIDER IN ACCORDANCE WITH THIS AGREEMENT, INCLUDING THE RESTRICTIONS AND OTHER TERMS AND CONDITIONS OF BIKE USE OUTLINED FOR RIDERS IN SECTION 2.16 WHICH APPLY TO EACH YOUTH RIDER;

(vii)         YOU WILL NOT PERMIT, AND WILL ENSURE THAT THE YOUTH RIDER DOES NOT, USE AN EBIKE AT ANY TIME; AND

(viii)        YOU ARE RESPONSIBLE FOR THE YOUTH RIDER’S COMPLIANCE WITH ALL APPLICABLE PROVISIONS OF THIS AGREEMENT.

2.18        CANCELLATION AND REFUNDS.  To cancel your membership, login to your Account at [www.mobibikes.ca or](http://www.mobibikes.ca.or/) on the Operator mobile app. If you cancel your membership, your Account will be maintained. To disable your Account, contact us at info@mobibikes.ca. When your Account is disabled, you can no longer access your Account. Operator offers refunds under limited circumstances. Please see the refund policy at <https://www.mobibikes.ca/en/refund-policy>.

2.19        NON-TRANSFERABLE.  Except to the extent provided in Section 2.14, Memberships are non-transferable and cannot be shared, and rental of Bikes is restricted to the Account holder.

2.20        ACCOUNT SUSPENSIONS.  The Operator reserves the right to suspend or cancel your Account without notice if you breach any provision of this Agreement. If your Account is suspended, you may be charged a reinstatement fee of up to $25 to reactivate your Account once a resolution in respect of the breach has been reached to the satisfaction of the Operator.

2.21        STOPOVER USAGE.  See Section 1.3(d) on the purpose and proper usage of Stopover. A Bike in Stopover is considered an active ride, and therefore, contributing to the overall Trip time included in your Pass or Membership. You are liable for all Claims for Bikes engaged in Stopover on your Account. To reduce liability for any fees resulting from a lost or stolen Bike while in Stopover, it is highly recommended to document the proper use of Stopover by taking a photo or video each time you engage Stopover and promptly sending such documentation to the Operator if the Bike becomes lost or stolen.

3.              RESTRICTIONS AND OTHER TERMS AND CONDITIONS OF BIKE USE.

3.1           REPRESENTATIONS AND WARRANTIES.  As a condition precedent to the Operator’s agreement to allow you to participate in the Bike Share Program and to rent a Bike, you represent and warrant to the Operator that:

(a)            You are at least twelve (12) years of age if using or renting a Classic Bike, and at least nineteen (19) years of age if using or renting an Ebike;

(b)            You (or your parent or legal guardian if Section 2.17 applies) are the legal holder of and named on the Credit Card used to rent a Bike in accordance with the terms of this Agreement;

(c)            You are experienced and familiar with the safe and competent operation of the Bike, and you are physically and mentally fit to ride the Bike;

(d)            You are familiar with all applicable rules, regulations, codes and laws that relate to the safe and legal operation of a bicycle; and

(e)            You will wear a helmet at all times that you are in motion on the Bike.

3.2           ACKNOWLEDGEMENTS AND AGREEMENTS.  As a condition precedent to the Operator’s agreement to allow you to participate in the Bike Share Program and to rent a Bike, you acknowledge and agrees as follows:

(a)            You are fully aware that riding a bicycle on streets poses a risk of accident due to motorists, pedestrians, and road conditions, and you must be aware and keep a proper lookout to avoid such accidents;

(b)            You are fully trained and capable of operating and riding a bicycle and are not relying in any way on the Operator to learn how to operate or ride a bicycle;

(c)            Failure to use a helmet or to use the Bike in a careful and reasonably competent manner may result in bodily injury or death to you and others, for which you accept full responsibility;

(d)            You are solely responsible for obtaining and using a helmet and proper clothing and shoes;

(e)            You are required to wear a helmet pursuant to the law of the Province of British Columbia;

(f)             A helmet, even when used, does not eliminate the risk of bodily injury in the event of an accident;

(g)            You are solely responsible for operating and riding a Bike in a careful and reasonably competent manner;

(h)            All Bikes are and shall remain the exclusive property of the Operator at all times;

(i)             You are solely responsible for any moving violations and fines incurred by you while using the Bike, including any fees for parking the Bike in prohibited locations or for riding without wearing a helmet;

(j)             The Operator is not obligated to provide insurance of any kind related to you or your use of the Bike, and in the event that the Operator, at its option, carries insurance, you shall remain liable for any liability, property damage, personal injury, injury to others, damages, penalties, fines, losses, and expenses of any kind whatsoever;

(k)            If you cause any damage to property or injury to another party while operating or in possession of the Bike, you are solely liable for all such damage or injury;

(l)             You shall return the Bike to the Operator in the same condition as when received;

(m)          You are liable for any and all damages resulting from improper use or abuse of the Bike and the full cost of such damages; and

(n)            The Operator provides Bikes as a service, and such rental availability is intended to be used only by those persons who are able and qualified to operate a Bike on their own and who have agreed to all terms and conditions of this Agreement.

3.3           REQUIREMENTS.  As a condition precedent to the Operator’s agreement to allow you to participate in the Bike Share Program and to rent a Bike, you shall:

(a)            put on a helmet and make sure it is fit properly to your head;

(b)            carefully inspect the Bike that you wish to rent prior to use to ensure the Bike is in good operating condition;

(c)            make sure the Lock is stored properly inside the handlebar during Bike use, and is used to lock the Bike whenever the Bike is not in use when away from Stations;

(d)            test the Bike’s operating components before proceeding with the intended use, including, but not limited to the brakes, tires, gears, pedals, lights, frame and saddle;

(e)            promptly notify the Operator customer service of any defect, malfunction or needed repair to a Bike;

(f)             adjust the Bike saddle to proper height prior to operating the Bike;

(g)            adjust Bike riding behavior for safe operation according to weather conditions;

(h)            only use Bike riding behavior that is that of a reasonably experienced and prudent bicycle rider;

(i)             stop riding and return the Bike to Station if the Bike is not functioning properly; and

(j)             contact the Operator and local police immediately in the event of theft of the Bike or an accident that occurs during your use of the Bike resulting in bodily injury,

(collectively, the “**Use Requirements**”).

3.4           RESTRICTED USES.  You shall not do any of the following at any time:

(a)            use any Bike if you are not wearing a helmet;

(b)            allow anyone who is younger than 19 years of age to use a Bike, except in accordance with Section 2.14 or 2.17;

(c)            use any Bike if you have any existing physical or mental condition that would prevent you from safely operating the Bike;

(d)            operate a Bike while carrying any item that impedes your ability to safely operate the Bike;

(e)            operate a Bike while under the influence of alcohol, drugs, or any other substance that impairs your ability to safely operate the Bike;

(f)             use any cell phone or electronic device, including, but not limited to, for the purposes of phone calls, text messages, music or any other use that distracts you, or has the potential to distract you, from the safe operation of the Bike;

(g)            allow any other person to use the Bike at the same time as yourself, or allow more than one person to be carried on the Bike at any time;

(h)            overfill the Bike basket or place objects weighing in total more 9 kilograms (20 pounds) in the Bike basket;

(i)             violate any applicable law or legal requirement while using a Bike;

(j)             operate or use a Bike in any manner during adverse weather conditions, including but not limited to: hail, snow, dust storms, fog, heavy rains, or lightning storms;

(k)            ride or operate a Bike that has any defect, fails to operate as a properly functioning bicycle, or that is in need of repair;

(l)             continue using the Bike if it, or any component of it, should become defective or malfunction;

(m)          use the Bike for racing (two or more riders competing to arrive at a particular location first), trick riding, jumping, stunt riding and/or, off-road riding;

(n)            use the Bike for any commercial purposes;

(o)            tow, pull, carry or push any person or object with a Bike;

(p)            remove, modify, or add any accessories, parts or components of any Bike;

(q)            ride the Bike without paying applicable user fee at the time they become due; and

(r)             use an Ebike, or permit any other individuals from using an Ebike, if under the age of 19,

(each a “**Restricted Use**”).

3.5           LOST AND FOUND POLICY. The Operator is not responsible for loss of or damage to a Rider’s property or the property of others left at any time in or on any Bike or on the Operator’s premises, even if it is in the Operator’s possession and regardless of who is at fault. The Operator is not obligated to contact a Rider regarding lost items belonging to the Rider, other authorized user(s), or any other person. The Operator is not obligated to remove a Bike from service due to loss of property and is not required to search any Bike for lost property.

3.6           LIMITED USE.  The Operator may limit your Account to the use of Classic Bikes only (i.e., no right to use Ebikes) if the Operator determines, in its sole discretion, that you have breached any provision of this Agreement, including repeat system abuse, or if a Bike rented under your Account has been lost or stolen, or has been deemed lost or stolen in accordance with this Agreement.

4.              SERVICE LIMITATIONS.

4.1           The Rider acknowledges and agrees that from and after the date that the Operator makes Bikes available to the public for rental, the Operator may, in its sole discretion: suspend all or part of its Bike Share Program at any time; relocate Stations; reduce the number of Bikes available for rent; and otherwise operate its Bike rental program in its sole discretion.

4.2           The Rider further acknowledges that the Operator may suspend the availability of Bikes during adverse weather conditions, or may be required to suspend the rental of Bikes by the city or applicable jurisdiction in which the Bikes are located.

4.3           The Rider shall not be entitled to a refund of any fees for unused rental periods unless the Operator’s Bike rental service shall have been suspended for a total of more than fifteen (15) days over the course of a twelve (12) month period.

4.4           The Rider acknowledges, understands and agrees that Operator does not represent or warrant that Bikes will be available for rental at any Station at any time.

4.5           The Operator may, in its sole discretion, require the return of any or all of its Bikes at any time.

5.              RELEASE AND LIMITATION OF LIABILITY.

5.1           FOR AND IN CONSIDERATION OF RENTAL AND USE OF THE BIKE, THE RIDER, FOR HIMSELF OR HERSELF AND ON BEHALF OF RIDER’S HEIRS, EXECUTORS, ADMINISTRATORS AND ASSIGNS, FOREVER RELEASES AND RELINQUISHES AND DISCHARGES (i) THE OPERATOR AND THE OPERATOR’S OFFICERS, BOARDS AND COMMISSIONS, MEMBERS, MANAGERS, EMPLOYEES, SUPPLIERS, AGENTS, REPRESENTATIVES, (ii) ANY MUNICIPALITY OR OTHER AUTHORITY WITH WHICH THE OPERATOR HAS CONTRACTED WITH TO PROVIDE A BIKE SHARE PROGRAM, AND (iii) ANY OWNER OF PROPERTY WITH WHICH THE OPERATOR, CITY OR OTHER APPLICABLE AUTHORITY HAS CONTRACTED WITH TO PROVIDE REAL PROPERTY ON WHICH A BIKE SHARE FACILITY, INCLUDING, WITHOUT LIMITATION, STATIONS, HUBS, RACKS, INTENDED FOR BIKE SHARE USE (ALL, COLLECTIVELY, THE “**OPERATOR PARTIES**”) FROM ANY AND ALL CLAIMS, DEMANDS, DISPUTES, LOSSES, LIABILITIES, DEBTS, LIENS, CHARGES, PENALTIES, PROCEEDINGS, CAUSES OF ACTION AND DAMAGES INCLUDING FOR PERSONAL INJURY, WRONGFUL DEATH, PROPERTY DAMAGE, AND INJURY TO RIDER OR TO THIRD PARTIES (COLLECTIVELY, “**CLAIMS**”), INCLUDING UNKNOWN OR UNANTICIPATED CLAIMS, WHICH ARISE FROM OR ARE RELATED DIRECTLY OR INDIRECTLY TO THIS AGREEMENT OR THE RENTAL, MAINTENANCE, DESIGN, USE AND/OR OPERATION OF THE OPERATOR EQUIPMENT, INCLUDING THE BIKES, OR THE OPERATOR WEBSITE, INCLUDING ANY AND ALL CLAIMS RELATED TO THE SOLE OR PARTIAL NEGLIGENCE OF OPERATOR, THE OPERATOR PARTIES OR ANY OTHER PARTY. THE RIDER HEREBY EXPRESSLY WAIVES ANY CLAIMS AGAINST THE OPERATOR PARTIES WHICH THE RIDER DOES NOT KNOW OR SUSPECT TO EXIST IN HIS OR HER FAVOR AT THE TIME OF RENTING A BIKE, AND EXPRESSLY WAIVES ALL OF THE RIDER'S RIGHTS UNDER ANY STATUTES THAT PURPORT TO PRESERVE THE RIDER'S UNKNOWN CLAIMS.

5.2           IF THE OPERATOR OR THE OPERATOR PARTIES ARE DEEMED TO HAVE ANY LIABILITY UNDER THIS AGREEMENT OR ARISING OUT OF A RIDER’S USE OF THE OPERATOR EQUIPMENT, INCLUDING THE BIKES, OR THE OPERATOR WEBSITE, SUCH LIABILITY SHALL NOT EXCEED THE AMOUNT OF THE MEMBERSHIP OR RENTAL PAID TO THE OPERATOR BY THE RIDER IN THE TWELVE (12) MONTHS PRECEDING THE DATE OF THE EVENT GIVING RISE TO SUCH LIABILITY.

6.              ASSUMPTIONS OF RISKS; DISCLAIMER.

6.1           THE RIDER EXPRESSLY ACKNOWLEDGES AND ACCEPTS THAT THE RIDER’S RENTAL AND USE OF THE BIKE IS AT HIS/HER OWN RISK. THE RIDER ACCEPTS THE BIKE FOR USE AFTER EXERCISING HIS/HER OWN FREE CHOICE TO PARTICIPATE VOLUNTARILY IN THIS ACTIVITY AND AFTER HAVING INSPECTED THE BIKE AND CERTIFYING THAT IS IN GOOD OPERATING CONDITION. THE RIDER UNDERSTANDS THAT BICYCLING MAY BE A HAZARDOUS ACTIVITY. THE RIDER ACKNOWLEDGES, UNDERSTANDS AND ASSUMES ALL RISK RELATING TO THE RENTAL, MAINTENANCE, DESIGN, USE AND/OR OPERATION OF THE OPERATOR EQUIPMENT, INCLUDING THE BIKES, AND THE OPERATOR WEBSITE AND UNDERSTANDS THAT BICYCLING INVOLVES RISK TO THE RIDER AND OTHERS INCLUDING DAMAGES, BODILY INJURY, PARTIAL OR TOTAL DISABILITY, PARALYSIS AND DEATH TO THE RIDER OR OTHERS, AND THAT THE RIDER HAS FULL KNOWLEDGE OF SAID RISKS AND DANGERS, INCLUDING SUCH RISKS, DAMAGES AND INJURIES THAT MAY ARISE FROM THE NEGLIGENCE OF OTHERS OR AS A RESULT OF ROADWAY CONDITIONS. ALL BIKES AND OTHER OPERATOR EQUIPMENT ARE PROVIDED “AS IS” AND WITHOUT ANY WARRANTY OF ANY KIND, WHETHER EXPRESS OR IMPLIED, WRITTEN OR ORAL, INCLUDING, WITHOUT LIMITATION, ANY WARRANTY OF MERCHANTABILITY, QUALITY OR FITNESS FOR A PARTICULAR PURPOSE. OPERATOR AND THE OPERATOR PARTIES HEREBY DISCLAIM ANY CLAIM IN TORT (INCLUDING NEGLIGENCE, PRODUCT LIABILITY OR STRICT LIABILITY).

6.2           IN NO EVENT WILL THE RIDER CLAIM THAT THE OPERATOR, OR ANY OF THE OPERATOR PARTIES INDIVIDUALLY OR COLLECTIVELY, FAILED TO ADEQUATELY TRAIN THE RIDER, OR PROVIDE THE RIDER WITH ADEQUATE INSTRUCTIONS NECESSARY TO RIDE THE BIKE IN THE SAME MANNER AS A PERSON WHO IS AN EXPERIENCED BICYCLE RIDER WHO HAS BEEN TRAINED TO RIDE A BICYCLE IN A SAFE AND CAREFUL MANNER.

7.              DISPUTE RESOLUTION.

7.1           The Rider agrees that the Operator, at its sole discretion, may submit any disputes whatsoever arising out of, resulting from, and/or relating to this Agreement, the Rider’s use of the Operator’s Equipment, including, without limitation, Bikes, and/or the Operator website, to final and binding arbitration under the rules of procedure of the British Columbia International Commercial Arbitration Centre by one or more arbitrators appointed in accordance with the said rules. In the event that the Operator submits such dispute to arbitration, then such arbitration shall be mandatory and binding on the parties. Such proceedings shall be held in the City of Vancouver. All arbitration proceedings will be conducted in the English language.

7.2           SHOULD THE OPERATOR NOT ELECT TO SUBMIT ANY DISPUTE OR CLAIM TO ARBITRATION, TO THE MAXIMUM EXTENT PERMITTED BY LAW, THE OPERATOR AND THE RIDER EACH WAIVE ANY RIGHT TO TRIAL BY JURY IN ANY LITIGATION OR TO HAVE A JURY PARTICIPATE IN RESOLVING ANY DISPUTE ARISING OUT OF OR WITH RESPECT TO THIS AGREEMENT OR THE RIDER’S USE OF THE OPERATOR’S EQUIPMENT, INCLUDING, WITHOUT LIMITATION, BIKES, AND/OR THE OPERATOR WEBSITE.

8.              INDEMNIFICATION.

8.1           The Rider shall indemnify, defend and hold harmless the Operator, the Operator Parties and the City of Vancouver for, from and against any and all Claims related to or arising out of this Agreement, including, but not limited to the Rider’s breach of any representations, warranties or covenants set forth in this Agreement, and the rental, maintenance, design, use or operation of the Bike, the Locks, the Stations and/or the Operator website, even where caused in whole or in part by the Operator’s negligence, and/or the negligence of others, whether presently known or unknown. At the Operator’s option, the Rider will assume control of the defense and settlement of any Claim subject to indemnification by the Rider (provided that, in such event, the Operator may at any time elect to take over control of the defense and settlement of any such Claim). In no event may the Rider settle any Claim without the Operator’s prior written consent.

9.              TERMINATION OF AGREEMENT.

9.1           The Rider acknowledges, understands and agrees that the Rider’s use of the Bike Share Program is “at the will” of the Operator, and that the Operator may terminate this Agreement at any time and cancel the Rider’s Account, without cause, legal process, or notice to the Rider. The Rider waives all claims, causes of actions, expenses, and/or damages connected and/or related to any such termination. The Rider shall not be entitled to a refund of any amount paid for unused rental periods if this Agreement is terminated for cause.

9.2           The Rider may terminate the Rider’s rental plan at any time; provided, however, that no refund will be provided by the Operator for time already used or not used by the Rider.

10.           FEE SCHEDULE.

10.1        OVERAGE FEES AND PENALTIES.

|  |  |  |
| --- | --- | --- |
|  | **Community**  **Pass Holder** | **General** |
| Overage Fees  Fees incurred when the Rider goes over the allotted ride time of their plan. | Classic Bike: $0.25 /min  Ebike: $0.35 /min | Classic Bike: $0.29 /min  Ebike: $0.19 /min |
| Late Return  Fee charged when a Bike notifies of a lock error and is left active at a station. | Classic Bike: $5  Ebike: $15 | Classic Bike: $15  Ebike: $30 |
| Loss of Use  Rate charged if a Bike is lost, stolen or forced out of use due to damage. Charged after the Bike is found. | Classic Bike: $5 /Day  Ebike: $15 /Day |
| Reinstatement Fee  Cost to reinstate membership after a Bike is reported missing or after an account has been suspended | $20 | $25 |
| Replacement Fee  Mobi reserves the right to charge up to the full cost of replacing equipment | Classic Bike: $2,000  Ebike: $4,000 |

10.2        RECOVERY, CLEANING AND DAMAGE FEES.

|  |  |
| --- | --- |
| Pick up & Recovery (within service area)  Cost of recovering, inspecting and rebalancing a Bike within Mobi’s service area (includes VPD pick-ups) | Up to $50 |
| Pick up & Recovery (outside of service area)  Cost of recovering, inspecting and rebalancing a Bike outside of Mobi’s service area | Up to $80 |
| Excessive cleaning fee  Extra cleaning required when a Bike is returned unusable due to uncleanliness | Up to $80 |
| Minor damage repair  If a Bike is damaged during your Rental Period of the Bike, beyond regular wear and tear, you shall be charged a fee that is equal to the cost of repairing such damage.  Ex. - Switching lights, saddle replacement, small graffiti | Up to $100 |
| Major damage repair  If a Bike is damaged during your Rental Period of the Bike, beyond regular wear and tear, you shall be charged a fee that is equal to the cost of repairing such damage.  Ex. - Full resticker, large graffiti, broken frame, wheels, forks, etc. | Up to the replacement fee |

11.           GENERAL PROVISIONS

11.1        ASSIGNMENT. The Operator may assign its rights and duties under this Agreement in its sole discretion to any party at any time without notice to the Rider.

11.2        NO WAIVER. The Operator’s failure to insist upon or enforce strict performance of any provision of this Agreement shall not be construed as a waiver of any provision or right. Neither the course of conduct between the parties nor trade practice shall act to modify any part of this Agreement. No waiver by the Operator shall be construed as a waiver of any preceding or succeeding breach of any provision in this Agreement.

11.3        SEVERABILITY. If any provision of this Agreement is held by a court of competent jurisdiction to be contrary to law, the remaining provisions of the Agreement shall remain in full force and effect.

11.4        SURVIVAL. All provisions of this Agreement relating to limitation and exclusion of liability, waivers, assumption of risk, warranties and indemnification obligations shall survive the termination of this Agreement, and all amounts unpaid at the time of termination or expiration of this Agreement shall remain due and payable.

11.5        REFUND POLICY. Rider may access Operator’s refund policy at: <https://www.mobibikes.ca/en/refund-policy>.

11.6        PRIVACY POLICY. Rider may access Operator’s privacy policy applicable to this Agreement at: <https://www.mobibikes.ca/en/privacy-policy>.

11.7        ENTIRE AGREEMENT. This Agreement constitutes the final and entire Agreement between the Operator and the Rider and prevails over any prior or contemporaneous, conflicting or additional communications and agreements that pertain to the matter of this Agreement, unless otherwise agreed to by the Parties in writing. The Operator shall have the right to revise, change and modify the terms and conditions contained in this Agreement at any time without prior written notification by posting the revised Agreement on [www.mobibikes.ca](http://www.vancouverbikeshare.ca/), and such changes shall apply to all future use of Bikes after the date of such changes. Riders shall be solely responsible for reviewing and becoming familiar with any modification to this Agreement. Use and/or operation of the Bike by the Rider following any modifications to this Agreement constitutes the Rider’s acceptance of the terms and conditions as modified.