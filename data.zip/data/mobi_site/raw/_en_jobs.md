# Jobs - Mobi by Rogers

**URL:** https://www.mobibikes.ca/en/jobs
**Description:** 
**Main Heading:** 
**Scraped:** 2025-11-10 22:46:24

---

#### WORK TOWARDS A BETTER FUTURE

Want to work in a fun and dynamic environment with passionate people? Apply to one of our current opportunities by emailing [jobs@mobibikes.ca](mailto:jobs@mobibikes.ca). Please include your resume, cover letter and the name of the position you are applying for.  
  
We acknowledge that Mobi by Rogers operates on the unceded, occupied, ancestral and traditional homelands of the xʷməθkwəy̓əm (Musqueam), Skwxwú7mesh (Squamish) and Səl̓ílwətaʔ/Selilwitulh (Tsleil-Waututh) Nations.

#### CURRENT OPPORTUNITIES:

#### [Bike Share Fleet Balancer – Permanent Full-Time](https://drive.google.com/file/d/1XYf8WxT59Hnhjq7LMZcTPQbd9bUSyTVX/view?usp=sharing)

#### Don't see any openings that are a good fit but still want to work with us? Just email us at [jobs@mobibikes.ca](mailto:jobs@mobibikes.ca) and tell us about yourself!

#### WHY JOIN MOBI BY ROGERS?

- Competitive wages
- Extended health and dental benefits plan for eligible full-time and part-time employees
- Flexible scheduling & some remote working possible (position dependant)
- Free use of Mobi by Rogers classic bikes and ebikes
- Secure bike parking and shower facilities at HQ
- Free period products in bathrooms
- Free bike tune-ups & repairs by our mechanics
- Discounts on industry gear and services
- Friends & family discounted membership pricing
- Work with others who are passionate about bikes and the sharing economy

We are committed to employment equity and encourage applications from people whose identity has typically been underrepresented in the cycling industry or community. This includes Indigenous persons, persons of colour, persons with disabilities, and trans and non-binary persons. We value the experiences and skills gained through non-traditional employment, including unpaid labour and community organizing. At Mobi, we are committed to recruiting and retaining a diverse workforce that represents the community we serve. Accommodations will be provided upon request during the selection process.